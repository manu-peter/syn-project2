let list = document.getElementById("list");
let uploadBtn = document.getElementById("upload-btn");

function uploader(event) {
    event.preventDefault();
    let data = new FormData(event.target);
    uploadBtn.value = "Uploading..";
    uploadBtn.disabled = true;
    fetch(`http://localhost:3001/api/upload`, {
        method: "post",
        body: data
    })
        .then(res => res.text())
        .then(data => {
            uploadBtn.value = "Upload";
            uploadBtn.disabled = false;
            alert(data);
        });
}

function selected(event) {
    let target = event.target;
    let files = target.files;
    list.innerHTML = ``;
    Object.values(files).forEach(file => {
        let tr = `
        <tr>
           <td>${fileType(file.type)}</td>
           <td>${file.name}</td>
           <td>${Size(file.size)}</td>
        `;
        list.innerHTML += tr;
    })
}

function fileType(type) {
    let t = type.split("/")[0];
    return t;
}

function Size(size) {
    let units = ["Bytes", "KB", "MB", "GB", "TB"];
    let pow = 0;
    while (Math.floor(size / 1000) !== 0) {
        pow++;
        size /= 1000;
    }
    return (`${size.toFixed(4)} ${units[pow]}`);
}